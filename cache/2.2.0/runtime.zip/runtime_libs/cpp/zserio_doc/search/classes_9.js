var searchData=
[
  ['readercontext',['ReaderContext',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html',1,'zserio::BitStreamReader']]]
];
