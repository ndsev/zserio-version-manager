var searchData=
[
  ['pre_5fwrite_5finitialize_5fchildren',['PRE_WRITE_INITIALIZE_CHILDREN',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890a0551d229fb835fea4982db512390a06c',1,'zserio']]],
  ['pre_5fwrite_5finitialize_5foffsets',['PRE_WRITE_INITIALIZE_OFFSETS',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890ae65758a46751a510315d7a1e615f2ea8',1,'zserio']]]
];
