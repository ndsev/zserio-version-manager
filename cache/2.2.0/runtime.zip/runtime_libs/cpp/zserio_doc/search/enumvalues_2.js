var searchData=
[
  ['internal_5fconnection',['INTERNAL_CONNECTION',['../classzserio_1_1SqliteConnection.html#a0e86953645a641eea026f8b5df99d24ba7b6bffcedbba5b6844b44e326e03ed4e',1,'zserio::SqliteConnection']]]
];
