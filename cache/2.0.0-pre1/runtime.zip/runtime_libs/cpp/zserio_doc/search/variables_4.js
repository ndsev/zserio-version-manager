var searchData=
[
  ['nullopt',['NullOpt',['../namespacezserio.html#a9036cb5fd7f4cd451d41eb5e994a8f70',1,'zserio']]]
];
