var searchData=
[
  ['optionalholder',['OptionalHolder',['../namespacezserio.html#a5ce0a7177f28e77d511426a3f9a2c747',1,'zserio']]]
];
