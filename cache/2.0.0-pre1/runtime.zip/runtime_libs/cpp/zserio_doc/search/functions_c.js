var searchData=
[
  ['serviceexception',['ServiceException',['../classzserio_1_1ServiceException.html#aa38f16867cf849c7b1a7bf309c0a483a',1,'zserio::ServiceException']]],
  ['set',['set',['../classzserio_1_1AnyHolder.html#a4227b0c588d1bc05aa2a46c492fcf227',1,'zserio::AnyHolder']]],
  ['setbitposition',['setBitPosition',['../classzserio_1_1BitStreamReader.html#aa40381d1c9d46ad2e1f957cf93151082',1,'zserio::BitStreamReader::setBitPosition()'],['../classzserio_1_1BitStreamWriter.html#aeca42f9095637f478cbc8786380d3b5c',1,'zserio::BitStreamWriter::setBitPosition()']]],
  ['sqliteconnection',['SqliteConnection',['../classzserio_1_1SqliteConnection.html#a5f3a3c806850a04410db1af8edc00897',1,'zserio::SqliteConnection::SqliteConnection(sqlite3 *connection=NULL, ConnectionType connectionType=INTERNAL_CONNECTION)'],['../classzserio_1_1SqliteConnection.html#a65f27bd52fdfd8dd4fa6f90b5cd82345',1,'zserio::SqliteConnection::SqliteConnection(const SqliteConnection &amp;)=delete'],['../classzserio_1_1SqliteConnection.html#a1fa8290998214ed136b956eb1fbe084d',1,'zserio::SqliteConnection::SqliteConnection(SqliteConnection &amp;&amp;)=delete']]],
  ['sqliteexception',['SqliteException',['../classzserio_1_1SqliteException.html#a6d289df7986bbdf5ff92ba0b1dd74bae',1,'zserio::SqliteException::SqliteException(const std::string &amp;message)'],['../classzserio_1_1SqliteException.html#aa417615e4129431ff491c789e4486a05',1,'zserio::SqliteException::SqliteException(const std::string &amp;message, int sqliteCode)']]],
  ['starttransaction',['startTransaction',['../classzserio_1_1SqliteConnection.html#accdf8298f8d5d945d4edab7b043602cc',1,'zserio::SqliteConnection']]]
];
