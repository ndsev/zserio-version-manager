var searchData=
[
  ['dynamic_5fextent',['dynamic_extent',['../namespacezserio.html#ad95672c11b9aa9116e1f3113585cd7ad',1,'zserio']]]
];
