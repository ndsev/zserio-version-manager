var searchData=
[
  ['no_5fpre_5fwrite_5faction',['NO_PRE_WRITE_ACTION',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890a6619b33a13f086d11501a6f0641eeed4',1,'zserio']]],
  ['normal',['NORMAL',['../namespacezserio.html#abf1b8023993fc6eb1de428b56a867b8fa72fb68339827e115f41c7f9e10e68f62',1,'zserio']]]
];
