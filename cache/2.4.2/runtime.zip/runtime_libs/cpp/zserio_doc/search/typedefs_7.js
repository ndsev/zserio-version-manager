var searchData=
[
  ['stringview',['StringView',['../namespacezserio.html#add1ed74fccd24644bfba4fc8294c9806',1,'zserio']]],
  ['subscriptionid',['SubscriptionId',['../classzserio_1_1IPubsub.html#a98b9eea3270b57fc7c3279b4f75bcb27',1,'zserio::IPubsub']]]
];
