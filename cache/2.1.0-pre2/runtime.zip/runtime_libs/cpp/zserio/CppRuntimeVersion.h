#ifndef ZSERIO_CPP_RUNTIME_VERSION_H_INC
#define ZSERIO_CPP_RUNTIME_VERSION_H_INC

/**
 * C++ extension runtime version string.
 */
#define CPP_EXTENSION_RUNTIME_VERSION_STRING "2.1.0-pre2"

#endif // ifndef ZSERIO_CPP_RUNTIME_VERSION_H_INC
