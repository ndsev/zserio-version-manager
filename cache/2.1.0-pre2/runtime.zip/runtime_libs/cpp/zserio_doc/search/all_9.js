var searchData=
[
  ['no_5fpre_5fwrite_5faction',['NO_PRE_WRITE_ACTION',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890a6619b33a13f086d11501a6f0641eeed4',1,'zserio']]],
  ['nullopt',['NullOpt',['../namespacezserio.html#a9036cb5fd7f4cd451d41eb5e994a8f70',1,'zserio']]],
  ['nullopttype',['NullOptType',['../structzserio_1_1NullOptType.html',1,'zserio']]],
  ['nullopttype',['NullOptType',['../structzserio_1_1NullOptType.html#a856e09717502b2c52e822dcee9dc33c5',1,'zserio::NullOptType']]]
];
