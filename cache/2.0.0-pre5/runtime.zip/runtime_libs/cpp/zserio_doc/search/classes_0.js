var searchData=
[
  ['anyholder',['AnyHolder',['../classzserio_1_1AnyHolder.html',1,'zserio']]]
];
