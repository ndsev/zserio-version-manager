var searchData=
[
  ['hasinternalbuffer',['hasInternalBuffer',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#aabd184fb5877bbd3c9a3206be8493382',1,'zserio::BitStreamReader::ReaderContext']]]
];
