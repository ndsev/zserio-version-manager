var searchData=
[
  ['no_5fpre_5fwrite_5faction',['NO_PRE_WRITE_ACTION',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890a6619b33a13f086d11501a6f0641eeed4',1,'zserio']]]
];
