var searchData=
[
  ['cache',['cache',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#aa846d100742d31bc9fb7174ae041dc60',1,'zserio::BitStreamReader::ReaderContext']]],
  ['cachenumbits',['cacheNumBits',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#ab1575a7681b173cd5f1a387e1c93979c',1,'zserio::BitStreamReader::ReaderContext']]]
];
