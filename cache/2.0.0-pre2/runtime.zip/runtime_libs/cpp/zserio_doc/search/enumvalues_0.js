var searchData=
[
  ['all_5fpre_5fwrite_5factions',['ALL_PRE_WRITE_ACTIONS',['../namespacezserio.html#a1f5f04f451180c18760681ab57dc1890a5680b3af9dd6bb6f52287ab072966b72',1,'zserio']]]
];
