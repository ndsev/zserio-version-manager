var searchData=
[
  ['heapoptionalholder',['HeapOptionalHolder',['../namespacezserio.html#ac98da4c1043f7dc7e22ce455f760657d',1,'zserio']]]
];
