var searchData=
[
  ['bitpostype',['BitPosType',['../classzserio_1_1BitStreamReader.html#a958beec975daad3585192fa48ff5856c',1,'zserio::BitStreamReader::BitPosType()'],['../classzserio_1_1BitStreamWriter.html#a9f38c25d8653e0cd948969bc88a8c685',1,'zserio::BitStreamWriter::BitPosType()']]]
];
