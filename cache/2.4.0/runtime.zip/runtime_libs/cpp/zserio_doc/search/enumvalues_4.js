var searchData=
[
  ['implicit',['IMPLICIT',['../namespacezserio.html#abf1b8023993fc6eb1de428b56a867b8fa56ee10490dad3244fe86c0d1ef2ceb0f',1,'zserio']]],
  ['internal_5fconnection',['INTERNAL_CONNECTION',['../classzserio_1_1SqliteConnection.html#a0e86953645a641eea026f8b5df99d24ba7b6bffcedbba5b6844b44e326e03ed4e',1,'zserio::SqliteConnection']]],
  ['invalid_5fcolumn_5fconstraint',['INVALID_COLUMN_CONSTRAINT',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a1f531c5faddbc5d806c0ae4dc4f9a4de',1,'zserio::IValidationObserver']]],
  ['invalid_5fcolumn_5ftype',['INVALID_COLUMN_TYPE',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a1b3e8f089f796f753fc24ec4e2947e85',1,'zserio::IValidationObserver']]],
  ['invalid_5fvalue',['INVALID_VALUE',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9ae73f38c9044227576b0872f900024ff7',1,'zserio::IValidationObserver']]]
];
