var searchData=
[
  ['memoryresource',['MemoryResource',['../classzserio_1_1pmr_1_1MemoryResource.html',1,'zserio::pmr']]]
];
