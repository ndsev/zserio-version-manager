var searchData=
[
  ['name',['name',['../structzserio_1_1ValidationSqliteUtil_1_1ColumnDescription.html#a930a9d1811a154deecda48ada6cca938',1,'zserio::ValidationSqliteUtil::ColumnDescription']]],
  ['npos',['npos',['../classzserio_1_1BasicStringView.html#a03332d4872991b4da3e99aee4c80650c',1,'zserio::BasicStringView']]],
  ['nullopt',['NullOpt',['../namespacezserio.html#a9036cb5fd7f4cd451d41eb5e994a8f70',1,'zserio']]]
];
