var searchData=
[
  ['choice',['CHOICE',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2ad8016e00648935707599e94ff896038f',1,'zserio::CHOICE()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721dad8016e00648935707599e94ff896038f',1,'zserio::CHOICE()']]],
  ['column_5fmissing',['COLUMN_MISSING',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a9c051c57e410ccfce390e2fc76c4821f',1,'zserio::IValidationObserver']]],
  ['column_5fsuperfluous',['COLUMN_SUPERFLUOUS',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9abdd846ce0e393c88d120f3a03895b771',1,'zserio::IValidationObserver']]]
];
