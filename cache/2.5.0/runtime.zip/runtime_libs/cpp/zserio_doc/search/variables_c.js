var searchData=
[
  ['value',['value',['../structzserio_1_1ItemInfo.html#ac2335a90d3bd1a25ebcbba80265950c7',1,'zserio::ItemInfo']]]
];
