var searchData=
[
  ['children',['Children',['../classzserio_1_1BasicPackingContextNode.html#a640af377b923e81ebe41dad32ad1a3fd',1,'zserio::BasicPackingContextNode']]]
];
