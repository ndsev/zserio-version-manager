var searchData=
[
  ['uniontypeinfo',['UnionTypeInfo',['../classzserio_1_1UnionTypeInfo.html#a076e056e6d5a252ff894bf8c2999c7f7',1,'zserio::UnionTypeInfo']]],
  ['unsubscribe',['unsubscribe',['../classzserio_1_1IPubsub.html#a7989ac82afbdfd9f8a0aad4cbc4b8dae',1,'zserio::IPubsub']]]
];
