var searchData=
[
  ['bit_5fbuffer',['BIT_BUFFER',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2aa7895161b771409b04054406ab80dbf5',1,'zserio']]],
  ['bitmask',['BITMASK',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2a0287e103671bf22378919a64d4b70699',1,'zserio::BITMASK()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da0287e103671bf22378919a64d4b70699',1,'zserio::BITMASK()']]],
  ['blob_5fcompare_5ffailed',['BLOB_COMPARE_FAILED',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9add9ad4e883e831f38742b91b00d23e8e',1,'zserio::IValidationObserver']]],
  ['blob_5fparse_5ffailed',['BLOB_PARSE_FAILED',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a26ba0256b412b4adb30c8fa019eed561',1,'zserio::IValidationObserver']]],
  ['bool',['BOOL',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2aa97b2c144243b2b9d2c593ec268b62f5',1,'zserio::BOOL()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721daa97b2c144243b2b9d2c593ec268b62f5',1,'zserio::BOOL()']]]
];
