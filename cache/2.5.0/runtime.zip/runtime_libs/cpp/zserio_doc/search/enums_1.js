var searchData=
[
  ['connectiontype',['ConnectionType',['../classzserio_1_1SqliteConnection.html#a0e86953645a641eea026f8b5df99d24b',1,'zserio::SqliteConnection']]],
  ['cpptype',['CppType',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2',1,'zserio']]]
];
