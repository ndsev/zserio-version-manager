var searchData=
[
  ['bitmaskreflectablearray',['BitmaskReflectableArray',['../namespacezserio.html#a49bb2f7b8d034875420253beb79da26e',1,'zserio']]],
  ['bitpostype',['BitPosType',['../classzserio_1_1BitStreamReader.html#a958beec975daad3585192fa48ff5856c',1,'zserio::BitStreamReader::BitPosType()'],['../classzserio_1_1BitStreamWriter.html#a9f38c25d8653e0cd948969bc88a8c685',1,'zserio::BitStreamWriter::BitPosType()']]]
];
