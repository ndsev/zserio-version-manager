var searchData=
[
  ['data',['data',['../classzserio_1_1Span.html#ab6bfa8a36101ac3f4a8d4c845a028e98',1,'zserio::Span::data()'],['../classzserio_1_1BasicStringView.html#ac3835c01a63540fd816959f51c8a2b7f',1,'zserio::BasicStringView::data()']]],
  ['deleteschema',['deleteSchema',['../classzserio_1_1ISqliteDatabase.html#a4b64e2afb1a41afc4298ee16456ee803',1,'zserio::ISqliteDatabase']]],
  ['deltacontext',['DeltaContext',['../classzserio_1_1DeltaContext.html',1,'zserio']]],
  ['deserialize',['deserialize',['../namespacezserio.html#ad7f14d8aadda0c526f3b2151c58bf3da',1,'zserio::deserialize(const BasicBitBuffer&lt; ALLOC &gt; &amp;bitBuffer, ARGS &amp;&amp;...arguments)'],['../namespacezserio.html#ae191f28f267323fce42e98bc9b24d1dd',1,'zserio::deserialize(const BasicBitBuffer&lt; ALLOC &gt; &amp;bitBuffer)']]],
  ['deserializefromfile',['deserializeFromFile',['../namespacezserio.html#ab2b738b9c5e2aab424944835c59f6ff4',1,'zserio']]],
  ['double',['DOUBLE',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2afd3e4ece78a7d422280d5ed379482229',1,'zserio']]],
  ['doublereflectable',['DoubleReflectable',['../classzserio_1_1DoubleReflectable.html',1,'zserio']]],
  ['dynamic_5fextent',['dynamic_extent',['../namespacezserio.html#ad95672c11b9aa9116e1f3113585cd7ad',1,'zserio']]],
  ['dynamic_5fsigned_5fbitfield',['DYNAMIC_SIGNED_BITFIELD',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721dad870aeddfc3c1c404a3bf9b131d3aa81',1,'zserio']]],
  ['dynamic_5funsigned_5fbitfield',['DYNAMIC_UNSIGNED_BITFIELD',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da73345568cf90582ce79309f2d108658a',1,'zserio']]]
];
