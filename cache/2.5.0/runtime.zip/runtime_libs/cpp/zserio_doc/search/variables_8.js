var searchData=
[
  ['propagateallocator',['PropagateAllocator',['../namespacezserio.html#a44f69be65008415a101279aa20b6a19f',1,'zserio']]]
];
