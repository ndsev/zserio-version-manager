var searchData=
[
  ['implicit',['IMPLICIT',['../namespacezserio.html#abf1b8023993fc6eb1de428b56a867b8fa56ee10490dad3244fe86c0d1ef2ceb0f',1,'zserio']]],
  ['int16',['INT16',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2a5f90af42814c0a419d715d43ae54fd7a',1,'zserio::INT16()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da5f90af42814c0a419d715d43ae54fd7a',1,'zserio::INT16()']]],
  ['int32',['INT32',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2a6495adba09844fac8eeb0aba86e6f1bf',1,'zserio::INT32()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da6495adba09844fac8eeb0aba86e6f1bf',1,'zserio::INT32()']]],
  ['int64',['INT64',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2a4e866b275c85fbb439f6484251cfb31c',1,'zserio::INT64()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da4e866b275c85fbb439f6484251cfb31c',1,'zserio::INT64()']]],
  ['int8',['INT8',['../namespacezserio.html#a3533b4966f6895549ed5cce32100adc2aee9d73311ff0658494edfff14c3ec1e3',1,'zserio::INT8()'],['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721daee9d73311ff0658494edfff14c3ec1e3',1,'zserio::INT8()']]],
  ['internal_5fconnection',['INTERNAL_CONNECTION',['../classzserio_1_1SqliteConnection.html#a0e86953645a641eea026f8b5df99d24ba7b6bffcedbba5b6844b44e326e03ed4e',1,'zserio::SqliteConnection']]],
  ['invalid_5fcolumn_5fconstraint',['INVALID_COLUMN_CONSTRAINT',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a1f531c5faddbc5d806c0ae4dc4f9a4de',1,'zserio::IValidationObserver']]],
  ['invalid_5fcolumn_5ftype',['INVALID_COLUMN_TYPE',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a1b3e8f089f796f753fc24ec4e2947e85',1,'zserio::IValidationObserver']]],
  ['invalid_5fvalue',['INVALID_VALUE',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9ae73f38c9044227576b0872f900024ff7',1,'zserio::IValidationObserver']]]
];
