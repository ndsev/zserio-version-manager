var searchData=
[
  ['ptr',['Ptr',['../classzserio_1_1IBasicReflectable.html#ad9c9e56195429c9c6b7ae2826159e16c',1,'zserio::IBasicReflectable']]]
];
