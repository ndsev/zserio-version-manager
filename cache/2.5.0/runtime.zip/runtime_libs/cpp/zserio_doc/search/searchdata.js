var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwz~",
  1: "abcdefimnoprstuv",
  2: "z",
  3: "abcdefghilmnoprstuvw~",
  4: "abcdfinoprstv",
  5: "abcehiprst",
  6: "aces",
  7: "abcdefinpsuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator"
};

