var searchData=
[
  ['typeinfofunc',['TypeInfoFunc',['../classzserio_1_1RecursiveTypeInfo.html#aae54c6f3b42629bbf60205ca3bf7289d',1,'zserio::RecursiveTypeInfo']]]
];
