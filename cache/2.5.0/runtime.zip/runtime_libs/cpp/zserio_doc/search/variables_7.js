var searchData=
[
  ['offset',['offset',['../structzserio_1_1FieldInfo.html#a8a45a003e16935c555dba8770718495c',1,'zserio::FieldInfo']]],
  ['optionalcondition',['optionalCondition',['../structzserio_1_1FieldInfo.html#a52388a6f64976c6a75db66a0f7f8bf2f',1,'zserio::FieldInfo']]]
];
