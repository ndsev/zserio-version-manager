var searchData=
[
  ['field',['field',['../structzserio_1_1CaseInfo.html#ae5bc9e15a3f6d60b9fc1324abc77bf98',1,'zserio::CaseInfo']]],
  ['functionresult',['functionResult',['../structzserio_1_1FunctionInfo.html#a275fe7bb5dfdbfc0972bdbba3e44605d',1,'zserio::FunctionInfo']]]
];
