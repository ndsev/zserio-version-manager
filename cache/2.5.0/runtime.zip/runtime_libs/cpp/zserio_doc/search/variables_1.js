var searchData=
[
  ['bitindex',['bitIndex',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#a063fa70868d9d7502ebf74a729f08056',1,'zserio::BitStreamReader::ReaderContext']]],
  ['buffer',['buffer',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#a06356aae0087732665bcaf4496a1491f',1,'zserio::BitStreamReader::ReaderContext']]],
  ['buffer32',['buffer32',['../unionzserio_1_1BitStreamReader_1_1ReaderContext_1_1BitCache.html#aa2794021c374507301c30951ad9659f2',1,'zserio::BitStreamReader::ReaderContext::BitCache']]],
  ['buffer64',['buffer64',['../unionzserio_1_1BitStreamReader_1_1ReaderContext_1_1BitCache.html#a0bff648a1284b591c0c8daee8f57b215',1,'zserio::BitStreamReader::ReaderContext::BitCache']]],
  ['bufferbitsize',['bufferBitSize',['../structzserio_1_1BitStreamReader_1_1ReaderContext.html#a50838b01dd24313a8564adb9f5340107',1,'zserio::BitStreamReader::ReaderContext']]]
];
