var searchData=
[
  ['schematype',['SchemaType',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721d',1,'zserio']]]
];
