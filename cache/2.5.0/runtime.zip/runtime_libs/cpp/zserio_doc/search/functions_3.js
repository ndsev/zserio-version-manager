var searchData=
[
  ['data',['data',['../classzserio_1_1Span.html#ab6bfa8a36101ac3f4a8d4c845a028e98',1,'zserio::Span::data()'],['../classzserio_1_1BasicStringView.html#ac3835c01a63540fd816959f51c8a2b7f',1,'zserio::BasicStringView::data()']]],
  ['deleteschema',['deleteSchema',['../classzserio_1_1ISqliteDatabase.html#a4b64e2afb1a41afc4298ee16456ee803',1,'zserio::ISqliteDatabase']]],
  ['deserialize',['deserialize',['../namespacezserio.html#ad7f14d8aadda0c526f3b2151c58bf3da',1,'zserio::deserialize(const BasicBitBuffer&lt; ALLOC &gt; &amp;bitBuffer, ARGS &amp;&amp;...arguments)'],['../namespacezserio.html#ae191f28f267323fce42e98bc9b24d1dd',1,'zserio::deserialize(const BasicBitBuffer&lt; ALLOC &gt; &amp;bitBuffer)']]],
  ['deserializefromfile',['deserializeFromFile',['../namespacezserio.html#ab2b738b9c5e2aab424944835c59f6ff4',1,'zserio']]]
];
