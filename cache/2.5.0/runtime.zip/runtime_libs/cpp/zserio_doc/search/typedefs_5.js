var searchData=
[
  ['ibasicreflectableptr',['IBasicReflectablePtr',['../namespacezserio.html#af36feb20c4f713a829d2ebac7e5ddedc',1,'zserio']]],
  ['ibasicservicedataptr',['IBasicServiceDataPtr',['../namespacezserio.html#a3626227ac2ee13433f4968d8e09bd0aa',1,'zserio']]],
  ['inplaceoptionalholder',['InplaceOptionalHolder',['../namespacezserio.html#afac88696d3a6e89f68c2196b1cff0ec8',1,'zserio']]],
  ['ireflectable',['IReflectable',['../namespacezserio.html#adc448b5264e6a84e26fca5e65850005e',1,'zserio']]],
  ['ireflectableptr',['IReflectablePtr',['../namespacezserio.html#a4823ee4de4271af00620c1d1c40c3b78',1,'zserio']]],
  ['is_5ffield_5fconstructor_5fenabled',['is_field_constructor_enabled',['../namespacezserio.html#a81ee0edbad335b9af502822475fa3669',1,'zserio']]],
  ['is_5ffield_5fconstructor_5fenabled_5ft',['is_field_constructor_enabled_t',['../namespacezserio.html#a7ae86dff238a9f22729ca7a9537c81da',1,'zserio']]],
  ['iservice',['IService',['../namespacezserio.html#a4bb3e5c3a1a10883f5c658e203c85f23',1,'zserio']]],
  ['iserviceclient',['IServiceClient',['../namespacezserio.html#ade33a26f701b20f992ba6486690f832c',1,'zserio']]],
  ['iservicedata',['IServiceData',['../namespacezserio.html#a59f31db159724904f4787335d7d6b070',1,'zserio']]],
  ['iservicedataptr',['IServiceDataPtr',['../namespacezserio.html#a80997d5c7c80270f065604c937213f85',1,'zserio']]]
];
