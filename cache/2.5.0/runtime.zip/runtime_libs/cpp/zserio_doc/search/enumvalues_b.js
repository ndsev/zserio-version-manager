var searchData=
[
  ['value_5fout_5fof_5frange',['VALUE_OUT_OF_RANGE',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a9f8151ee83e54a4f26db3e4718244c70',1,'zserio::IValidationObserver']]],
  ['varint',['VARINT',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721dad1441bc7cefd4cf4dc1282282ae5c529',1,'zserio']]],
  ['varint16',['VARINT16',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da34b251d3a0ce626f09ae553dac6d1f77',1,'zserio']]],
  ['varint32',['VARINT32',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da8fc739137a22e7d138147ddf3234af8f',1,'zserio']]],
  ['varint64',['VARINT64',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da47e34c336d48f1dbd68229446c628322',1,'zserio']]],
  ['varsize',['VARSIZE',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721dac23cf65e93f7ebfd9ed0b9078839c7c0',1,'zserio']]],
  ['varuint',['VARUINT',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721dae58e42abfc983fd7310aea9b7a031b5d',1,'zserio']]],
  ['varuint16',['VARUINT16',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da7c4157314157f8b5d05b34b63c4df165',1,'zserio']]],
  ['varuint32',['VARUINT32',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da63a8128b6d7dee611195c4301cbc59d0',1,'zserio']]],
  ['varuint64',['VARUINT64',['../namespacezserio.html#a8234f31c7aa693caeda7416a00b3721da3f32054b9180b8371c3508fdcf3fa134',1,'zserio']]]
];
