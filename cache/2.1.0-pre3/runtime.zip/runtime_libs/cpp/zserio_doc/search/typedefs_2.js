var searchData=
[
  ['inplaceoptionalholder',['InPlaceOptionalHolder',['../namespacezserio.html#a0b9a28472f0cea64028da49b1c64ec89',1,'zserio']]]
];
