var searchData=
[
  ['objectarraytraits',['ObjectArrayTraits',['../classzserio_1_1ObjectArrayTraits.html',1,'zserio']]],
  ['objectarraytraits_3c_20t_20_3e',['ObjectArrayTraits&lt; T &gt;',['../classzserio_1_1ObjectArrayTraits_3_01T_01_4.html',1,'zserio']]]
];
