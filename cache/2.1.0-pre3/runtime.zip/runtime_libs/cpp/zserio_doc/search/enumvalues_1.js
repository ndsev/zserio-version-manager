var searchData=
[
  ['external_5fconnection',['EXTERNAL_CONNECTION',['../classzserio_1_1SqliteConnection.html#a0e86953645a641eea026f8b5df99d24ba0ebb8f75d49a6151dc61f1ec83c92ddb',1,'zserio::SqliteConnection']]]
];
