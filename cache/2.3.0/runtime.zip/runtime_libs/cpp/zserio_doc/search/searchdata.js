var indexSectionsWithContent =
{
  0: "abcdefghinoprstuvwz~",
  1: "abcefinoprsv",
  2: "z",
  3: "abcdeghinoprsuvw~",
  4: "bchin",
  5: "bhiost",
  6: "cp",
  7: "aeinp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator"
};

