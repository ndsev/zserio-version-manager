var searchData=
[
  ['inplaceoptionalholder',['InplaceOptionalHolder',['../namespacezserio.html#afac88696d3a6e89f68c2196b1cff0ec8',1,'zserio']]],
  ['is_5ffield_5fconstructor_5fenabled',['is_field_constructor_enabled',['../namespacezserio.html#a81ee0edbad335b9af502822475fa3669',1,'zserio']]],
  ['is_5ffield_5fconstructor_5fenabled_5ft',['is_field_constructor_enabled_t',['../namespacezserio.html#a7ae86dff238a9f22729ca7a9537c81da',1,'zserio']]]
];
