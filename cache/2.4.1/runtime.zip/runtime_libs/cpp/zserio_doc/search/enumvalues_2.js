var searchData=
[
  ['column_5fmissing',['COLUMN_MISSING',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9a9c051c57e410ccfce390e2fc76c4821f',1,'zserio::IValidationObserver']]],
  ['column_5fsuperfluous',['COLUMN_SUPERFLUOUS',['../classzserio_1_1IValidationObserver.html#aa76c80e84231f2efe921678ad50137e9abdd846ce0e393c88d120f3a03895b771',1,'zserio::IValidationObserver']]]
];
