var searchData=
[
  ['heapoptionalholder',['HeapOptionalHolder',['../namespacezserio.html#abf9d48a09d8c7b3460e5c01eed45da85',1,'zserio']]]
];
